﻿namespace PathfindingVisualization
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.UI_listView = new System.Windows.Forms.ListView();
            this.Identifier = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.X = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Y = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.UI_OriginBtn = new System.Windows.Forms.Button();
            this.UI_PointBtn = new System.Windows.Forms.Button();
            this.UI_CalcBtn = new System.Windows.Forms.Button();
            this.UI_delPtBtn = new System.Windows.Forms.Button();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // UI_listView
            // 
            this.UI_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Identifier,
            this.X,
            this.Y});
            this.UI_listView.FullRowSelect = true;
            this.UI_listView.HideSelection = false;
            this.UI_listView.Location = new System.Drawing.Point(175, 12);
            this.UI_listView.Name = "UI_listView";
            this.UI_listView.Size = new System.Drawing.Size(295, 429);
            this.UI_listView.TabIndex = 0;
            this.UI_listView.UseCompatibleStateImageBehavior = false;
            this.UI_listView.View = System.Windows.Forms.View.Details;
            // 
            // Identifier
            // 
            this.Identifier.Text = "Identifier";
            this.Identifier.Width = 100;
            // 
            // X
            // 
            this.X.Text = "X";
            this.X.Width = 100;
            // 
            // Y
            // 
            this.Y.Text = "Y";
            this.Y.Width = 100;
            // 
            // UI_OriginBtn
            // 
            this.UI_OriginBtn.Location = new System.Drawing.Point(13, 40);
            this.UI_OriginBtn.Name = "UI_OriginBtn";
            this.UI_OriginBtn.Size = new System.Drawing.Size(141, 44);
            this.UI_OriginBtn.TabIndex = 1;
            this.UI_OriginBtn.Text = "Set Origin";
            this.UI_OriginBtn.UseVisualStyleBackColor = true;
            this.UI_OriginBtn.Click += new System.EventHandler(this.UI_OriginBtn_Click);
            // 
            // UI_PointBtn
            // 
            this.UI_PointBtn.Enabled = false;
            this.UI_PointBtn.Location = new System.Drawing.Point(13, 121);
            this.UI_PointBtn.Name = "UI_PointBtn";
            this.UI_PointBtn.Size = new System.Drawing.Size(141, 35);
            this.UI_PointBtn.TabIndex = 2;
            this.UI_PointBtn.Text = "Add Point";
            this.UI_PointBtn.UseVisualStyleBackColor = true;
            this.UI_PointBtn.Click += new System.EventHandler(this.UI_PointBtn_Click);
            // 
            // UI_CalcBtn
            // 
            this.UI_CalcBtn.Enabled = false;
            this.UI_CalcBtn.Location = new System.Drawing.Point(12, 272);
            this.UI_CalcBtn.Name = "UI_CalcBtn";
            this.UI_CalcBtn.Size = new System.Drawing.Size(142, 42);
            this.UI_CalcBtn.TabIndex = 3;
            this.UI_CalcBtn.Text = "Find Path";
            this.UI_CalcBtn.UseVisualStyleBackColor = true;
            this.UI_CalcBtn.Click += new System.EventHandler(this.UI_CalcBtn_Click);
            // 
            // UI_delPtBtn
            // 
            this.UI_delPtBtn.Enabled = false;
            this.UI_delPtBtn.Location = new System.Drawing.Point(13, 192);
            this.UI_delPtBtn.Name = "UI_delPtBtn";
            this.UI_delPtBtn.Size = new System.Drawing.Size(141, 45);
            this.UI_delPtBtn.TabIndex = 4;
            this.UI_delPtBtn.Text = "Delete Point";
            this.UI_delPtBtn.UseVisualStyleBackColor = true;
            this.UI_delPtBtn.Click += new System.EventHandler(this.UI_delPtBtn_Click);
            // 
            // Timer1
            // 
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 453);
            this.Controls.Add(this.UI_delPtBtn);
            this.Controls.Add(this.UI_CalcBtn);
            this.Controls.Add(this.UI_PointBtn);
            this.Controls.Add(this.UI_OriginBtn);
            this.Controls.Add(this.UI_listView);
            this.Name = "Form1";
            this.Text = "Pathfinder Visualization";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView UI_listView;
        private System.Windows.Forms.Button UI_OriginBtn;
        private System.Windows.Forms.Button UI_PointBtn;
        private System.Windows.Forms.Button UI_CalcBtn;
        private System.Windows.Forms.Button UI_delPtBtn;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.ColumnHeader Identifier;
        private System.Windows.Forms.ColumnHeader X;
        private System.Windows.Forms.ColumnHeader Y;
    }
}

