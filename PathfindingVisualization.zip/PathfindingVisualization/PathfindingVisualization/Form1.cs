﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GDIDrawer;

namespace PathfindingVisualization
{
    public partial class Form1 : Form
    {
        private struct Target       //Structure containing information for a point including type and position
        {
            public Point _pt;
            public string _name;
            public Color _color;
        }
        List<Target> targets = new List<Target>();  //List of our various targets. Index 0 is our origin
        bool _origin = true;        //Boolean to let us know whether or not we are getting an origin point our a destination point
        CDrawer _canvas = new CDrawer(600, 600); //Initalize drawing window


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Create grid
            drawGrid(_canvas);
            Target tmp = new Target();
            targets.Add(tmp);


        }


        private void UI_OriginBtn_Click(object sender, EventArgs e)
        {
            Timer1.Enabled = true;
            _origin = true;


        }
        //Occurs on timer tick when relevant buttons are pressed to enabled
        private void Timer1_Tick(object sender, EventArgs e)
        {
            Target tmp = new Target();      //Current point being created
            if (_canvas.GetLastMouseLeftClick(out tmp._pt))
            {
                //Putting the point to a grid marker
                tmp._pt = roundPt(tmp._pt);
                //Give the point its name

                if (_origin)
                {
                    tmp._name = "Origin";
                    tmp._color = Color.Green;


                    if (targets[0]._name == "Origin")
                    {
                        targets.RemoveAt(0);
                        targets.Insert(0, tmp);
                    }
                    else
                    {
                        if (targets.Count == 1)
                        {
                            targets.RemoveAt(0);
                            targets.Insert(0, tmp);
                        }
                        else
                        {
                            targets.Insert(0, tmp);
                        }


                    }


                    _origin = false;
                }

                else
                {
                    tmp._name = "Destination";
                    tmp._color = Color.Blue;
                    targets.Add(tmp);

                }

                update();
                Timer1.Enabled = false;
            }


        }
        //Draw the background grid on the canvas.
        public void drawGrid(CDrawer canvas)
        {
            //Vertical lines
            for (int x = 50; x < 600; x += 50)
            {
                for (int y = 0; y < 600; y++)
                {
                    canvas.SetBBPixel(x, y, Color.Red);
                }
            }
            //Horizontal lines
            for (int y = 50; y < 600; y += 50)
            {
                for (int x = 0; x < 600; x++)
                {
                    canvas.SetBBPixel(x, y, Color.Red);
                }
            }
        }
        //Rounds the point to be drawn
        public Point roundPt(Point pt)
        {
            //X values
            int x = pt.X % 50;
            if (x > 25)
                pt.X += (50 - x);
            else
                pt.X -= x;
            //Y values
            int y = pt.Y % 50;
            if (y > 25)
                pt.Y += (50 - y);
            else
                pt.Y -= y;
            //Return the point
            return pt;
        }

        private void UI_PointBtn_Click(object sender, EventArgs e)
        {
            Timer1.Enabled = true;

        }
        //Delete currently selected listview item
        private void UI_delPtBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //Get index of selected items to deleted and delete them
                ListView.SelectedIndexCollection indexes = UI_listView.SelectedIndices;
                foreach (int i in indexes)
                {

                    targets.RemoveAt(i);
                    UI_listView.Items.RemoveAt(i);



                }
                //Clear canvas. Update everything
                update();

            }
            catch
            {

            }
        }
        //Updates the screen and listview
        private void update()
        {
            _canvas.Clear();
            UI_listView.Items.Clear();
            foreach (Target current in targets)
            {
                ListViewItem lvi = new ListViewItem(current._name);
                lvi.SubItems.Add(current._pt.X.ToString());
                lvi.SubItems.Add(current._pt.Y.ToString());
                UI_listView.Items.Add(lvi);
                _canvas.AddCenteredEllipse(current._pt, 10, 10, current._color);
            }
            if (!UI_PointBtn.Enabled)
            {
                UI_PointBtn.Enabled = true;
            }
            if (targets.Count > 1)
            {
                UI_CalcBtn.Enabled = true;
                UI_delPtBtn.Enabled = true;
            }
            if (targets[0]._name != "Origin")
            {
                UI_CalcBtn.Enabled = false;
                UI_PointBtn.Enabled = false;
                UI_delPtBtn.Enabled = false;

            }
            if (!(targets.Count > 1))
            {
                UI_CalcBtn.Enabled = false;
                UI_delPtBtn.Enabled = false;

            }
        }
        //Occurs when calculate button clicked.
        private void UI_CalcBtn_Click(object sender, EventArgs e)
        {
            findPath(targets);
        }
        //Finds the shortest path to all points recursively and draws the lines
        private void findPath(List<Target> targets)
        {
            try
            {
                Target origin = targets[0];
                int min = -1;
                int index = 0;
                //Find index of closest point
                for (int i = 1; i < targets.Count(); i++)
                {
                    int xDistance = Math.Abs(origin._pt.X - targets[i]._pt.X);
                    int yDistance = Math.Abs(origin._pt.Y - targets[i]._pt.Y);
                    int dist = xDistance + yDistance;
                    if (min == -1)
                    {
                        min = (dist);
                        index = i;
                    }

                    else if (dist < min)
                    {
                        min = dist;
                        index = i;
                    }

                }
                //Draw lines to that point

                //Create a little animation so the user can see
                if (targets[index]._pt.X > origin._pt.X)
                {

                    for (int x = origin._pt.X; x < targets[index]._pt.X; x += 50)
                    {
                        _canvas.AddLine(x, origin._pt.Y, x + 50, origin._pt.Y, Color.Yellow, 2);
                        System.Threading.Thread.Sleep(500);
                    }

                }
                else
                {
                    for (int x = origin._pt.X; x > targets[index]._pt.X; x -= 50)
                    {
                        _canvas.AddLine(x, origin._pt.Y, x - 50, origin._pt.Y, Color.Yellow, 2);
                        System.Threading.Thread.Sleep(500);
                    }
                }

                System.Threading.Thread.Sleep(500);
                if (targets[index]._pt.Y > origin._pt.Y)
                {

                    for (int y = origin._pt.Y; y < targets[index]._pt.Y; y += 50)
                    {
                        _canvas.AddLine(targets[index]._pt.X, y, targets[index]._pt.X, y + 50, Color.Yellow, 2);
                        System.Threading.Thread.Sleep(500);
                    }

                }
                else
                {
                    for (int y = origin._pt.Y; y > targets[index]._pt.Y; y -= 50)
                    {
                        _canvas.AddLine(targets[index]._pt.X, y, targets[index]._pt.X, y - 50, Color.Yellow, 2);
                        System.Threading.Thread.Sleep(500);
                    }
                }

                if (targets.Count > 2)
                {
                    targets.RemoveAt(0);
                    targets.Insert(0, targets[index - 1]);
                    targets.RemoveAt(index);
                    findPath(targets);
                }
            }
            catch
            {

            }

        }
    }

}
